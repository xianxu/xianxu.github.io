local opts = {
	shiftwidth = 4,
	tabstop = 4,
	expandtab = true,
	wrap = true,
	termguicolors = true,
	number = true,
	relativenumber = true,
	clipboard = "unnamedplus"
}

-- Set options from table
for opt, val in pairs(opts) do
	vim.o[opt] = val
end

-- Set other options
local colorscheme = require("helpers.colorscheme")
vim.cmd.colorscheme(colorscheme)

vim.api.nvim_create_autocmd("FileType", {
  pattern = { "markdown", "text", "gitcommit" }, -- Add more types if needed
  callback = function()
    vim.opt_local.spell = true
    vim.opt_local.spelllang = "en_us"
  end,
})

